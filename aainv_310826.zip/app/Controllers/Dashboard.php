<?php

namespace App\Controllers;

use App\Models\ProductModel;
use App\Models\SupplierModel;
use App\Models\CustomerModel;
use App\Models\ProjectModel;
use App\Models\PurchaseModel;
use App\Models\SaleModel;
use App\Models\PaymentModel;
use App\Models\ExpenseModel;
use CodeIgniter\Controller;

class Dashboard extends Controller
{
    public function index()
    {
        $db = \Config\Database::connect();

        $data['total_products']   = (new ProductModel())->countAll();
        $data['total_suppliers']  = (new SupplierModel())->countAll();
        $data['total_customers']  = (new CustomerModel())->countAll();
        $data['active_projects']  = (new ProjectModel())->where('status', 'ACTIVE')->countAllResults();

        $data['total_sales']      = $db->query("SELECT COALESCE(SUM(total_amount),0) AS t FROM sales")->getRow()->t;
        $data['total_purchases']  = $db->query("SELECT COALESCE(SUM(total_amount),0) AS t FROM purchases")->getRow()->t;
        $data['total_expenses']   = $db->query("SELECT COALESCE(SUM(amount),0) AS t FROM expenses")->getRow()->t;
        $data['total_payments']   = $db->query("SELECT COALESCE(SUM(amount),0) AS t FROM payments")->getRow()->t;
        $data['total_outstanding']= $db->query("SELECT COALESCE(SUM(balance_amount),0) AS t FROM sales")->getRow()->t;
		
		// CURRENT MONTH SALES
		$data['month_sales'] = $db->query("
			SELECT COALESCE(SUM(total_amount),0) AS t 
			FROM sales 
			WHERE MONTH(created_at) = MONTH(CURRENT_DATE())
			AND YEAR(created_at) = YEAR(CURRENT_DATE())
		")->getRow()->t;

		// CURRENT MONTH PURCHASES
		$data['month_purchases'] = $db->query("
			SELECT COALESCE(SUM(total_amount),0) AS t 
			FROM purchases 
			WHERE MONTH(created_at) = MONTH(CURRENT_DATE())
			AND YEAR(created_at) = YEAR(CURRENT_DATE())
		")->getRow()->t;

		// CURRENT MONTH EXPENSES
		$data['month_expenses'] = $db->query("
			SELECT COALESCE(SUM(amount),0) AS t 
			FROM expenses 
			WHERE MONTH(created_at) = MONTH(CURRENT_DATE())
			AND YEAR(created_at) = YEAR(CURRENT_DATE())
		")->getRow()->t;

        $data['recent_sales'] = $db->query("
            SELECT s.*, p.name AS project_name, c.name AS customer_name
            FROM sales s
            LEFT JOIN projects p ON s.project_id = p.id
            LEFT JOIN customers c ON s.customer_id = c.id
            ORDER BY s.created_at DESC LIMIT 5
        ")->getResultArray();

        $data['recent_purchases'] = $db->query("
            SELECT pu.*, s.name AS supplier_name, p.name AS project_name
            FROM purchases pu
            LEFT JOIN suppliers s ON pu.supplier_id = s.id
            LEFT JOIN projects p ON pu.project_id = p.id
            ORDER BY pu.created_at DESC LIMIT 5
        ")->getResultArray();


        return view('dashboard/index', $data);
    }
}

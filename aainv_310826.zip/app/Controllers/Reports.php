<?php

namespace App\Controllers;

use App\Models\ProjectModel;
use CodeIgniter\Controller;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Color;

use Dompdf\Dompdf;
use Dompdf\Options;

class Reports extends Controller
{
    public function index()
    {
        return view('reports/index');
    }

    public function profitLoss()
    {
        $db        = \Config\Database::connect();
        $projectId = $this->request->getGet('project_id');
        $startDate = $this->request->getGet('start_date');
        $endDate   = $this->request->getGet('end_date');

        $whereProject   = $projectId ? "AND s.project_id = $projectId" : "";
        $wherePurchProj = $projectId ? "AND pu.project_id = $projectId" : "";
        $whereExpProj   = $projectId ? "AND e.project_id = $projectId" : "";

        $dateFilterSale = "";
        $dateFilterPurch = "";
        $dateFilterExp = "";

        if ($startDate) {
            $dateFilterSale  .= " AND s.sale_date >= '$startDate'";
            $dateFilterPurch .= " AND pu.purchase_date >= '$startDate'";
            $dateFilterExp   .= " AND e.expense_date >= '$startDate'";
        }
        if ($endDate) {
            $dateFilterSale  .= " AND s.sale_date <= '$endDate'";
            $dateFilterPurch .= " AND pu.purchase_date <= '$endDate'";
            $dateFilterExp   .= " AND e.expense_date <= '$endDate'";
        }

        $projectModel = new ProjectModel();

        // Release 1.6B (Approved Design Decision 5): COGS is allocation-aware —
        // only the project_qty portion of each purchase line counts, not the
        // full supplier invoice (purchases.total_amount).
        $data['total_revenue']  = (float)$db->query("SELECT COALESCE(SUM(total_amount),0) AS t FROM sales s WHERE 1=1 $whereProject 		                                     $dateFilterSale")->getRow()->t;
        $data['total_cogs']     = array_sum($projectModel->getAllocatedPurchaseCostByProject($projectId ?: null, $startDate ?: null, $endDate ?: null));
        $data['total_expenses'] = (float)$db->query("SELECT COALESCE(SUM(amount),0) AS t FROM expenses e WHERE 1=1 $whereExpProj                                                 $dateFilterExp")->getRow()->t;
        $data['gross_profit']   = $data['total_revenue'] - $data['total_cogs'];
        $data['net_profit']     = $data['gross_profit'] - $data['total_expenses'];

        $data['project_breakdown'] = $db->query("
            SELECT pr.id, pr.name AS project_name,
                COALESCE(SUM(DISTINCT s.total_amount),0) AS revenue,
                COALESCE(SUM(DISTINCT e.amount),0) AS expenses
            FROM projects pr
            LEFT JOIN sales s ON s.project_id = pr.id
            LEFT JOIN expenses e ON e.project_id = pr.id
            GROUP BY pr.id, pr.name
            ORDER BY revenue DESC
        ")->getResultArray();

        $costByProject = $projectModel->getAllocatedPurchaseCostByProject();
        foreach ($data['project_breakdown'] as &$pb) {
            $pb['cogs'] = $costByProject[(int) $pb['id']] ?? 0.0;
        }
        unset($pb);

        $data['projects']   = (new ProjectModel())->orderBy('name','ASC')->findAll();
        $data['project_id'] = $projectId;
        $data['start_date'] = $startDate;
        $data['end_date']   = $endDate;

        return view('reports/profit_loss', $data);
    }
	
	public function profitLossExport()
	{
		$db        = \Config\Database::connect();
		$projectId = $this->request->getGet('project_id');
		$startDate = $this->request->getGet('start_date');
		$endDate   = $this->request->getGet('end_date');

		$dateFilterSale = "";
		$dateFilterPurch = "";
		$dateFilterExp = "";

		if ($startDate) {
			$dateFilterSale  .= " AND s.sale_date >= '$startDate'";
			$dateFilterPurch .= " AND pu.purchase_date >= '$startDate'";
			$dateFilterExp   .= " AND e.expense_date >= '$startDate'";
		}
		if ($endDate) {
			$dateFilterSale  .= " AND s.sale_date <= '$endDate'";
			$dateFilterPurch .= " AND pu.purchase_date <= '$endDate'";
			$dateFilterExp   .= " AND e.expense_date <= '$endDate'";
		}

		$rows = $db->query("
			SELECT pr.id, pr.name AS project_name,
				COALESCE(SUM(DISTINCT s.total_amount),0) AS revenue,
				COALESCE(SUM(DISTINCT e.amount),0) AS expenses
			FROM projects pr
			LEFT JOIN sales s ON s.project_id = pr.id
			LEFT JOIN expenses e ON e.project_id = pr.id
			WHERE 1=1
			" . ($projectId ? " AND pr.id = $projectId" : "") . "
			$dateFilterSale
			$dateFilterExp
			GROUP BY pr.id, pr.name
			ORDER BY revenue DESC
		")->getResultArray();

		// Release 1.6B (Approved Design Decision 5): COGS is allocation-aware —
		// only the project_qty portion of each purchase line, not the full
		// supplier invoice.
		$costByProject = (new ProjectModel())->getAllocatedPurchaseCostByProject($projectId ?: null, $startDate ?: null, $endDate ?: null);
		foreach ($rows as &$r) {
			$r['cogs'] = $costByProject[(int) $r['id']] ?? 0.0;
		}
		unset($r);

		// ===== CREATE EXCEL =====
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();
		$sheet->freezePane('A7');

		// ===== TITLE =====
		$sheet->mergeCells('A1:F1');
		$sheet->setCellValue('A1', 'PROFIT & LOSS REPORT');

		$sheet->mergeCells('A2:F2');
		$sheet->setCellValue('A2', 'Generated On: ' . date('d-m-Y h:i A'));

		// ===== PROJECT =====
		if ($projectId) {
			$projectName = $db->query("SELECT name FROM projects WHERE id = $projectId")->getRow()->name ?? '';
			$sheet->mergeCells('A3:F3');
			$sheet->setCellValue('A3', 'Project: ' . $projectName);
		} else {
			$sheet->mergeCells('A3:F3');
			$sheet->setCellValue('A3', 'Project: All Projects');
		}

		// ===== DATE =====
		if ($startDate || $endDate) {
			$sheet->mergeCells('A4:F4');
			$sheet->setCellValue('A4', 'Period: ' . ($startDate ?: 'Start') . ' to ' . ($endDate ?: 'End'));
		}

		// ===== TABLE HEADER =====
		$sheet->setCellValue('A6', 'Project');
		$sheet->setCellValue('B6', 'Revenue');
		$sheet->setCellValue('C6', 'COGS');
		$sheet->setCellValue('D6', 'Gross Profit');
		$sheet->setCellValue('E6', 'Expenses');
		$sheet->setCellValue('F6', 'Net Profit');

		// ===== DATA =====
		$rowNum = 7;

		foreach ($rows as $r) {
			$gross = $r['revenue'] - $r['cogs'];
			$net   = $gross - $r['expenses'];

			$sheet->setCellValue('A' . $rowNum, $r['project_name']);
			$sheet->setCellValue('B' . $rowNum, $r['revenue']);
			$sheet->setCellValue('C' . $rowNum, $r['cogs']);
			$sheet->setCellValue('D' . $rowNum, $gross);
			$sheet->setCellValue('E' . $rowNum, $r['expenses']);
			$sheet->setCellValue('F' . $rowNum, $net);

			$rowNum++;
		}

		// ===== AUTO SIZE =====
		foreach (range('A','F') as $col) {
			$sheet->getColumnDimension($col)->setAutoSize(true);
		}
		
		// ===== TITLE STYLE =====
		$sheet->getStyle('A1:F2')->getFill()->setFillType(Fill::FILL_SOLID)
			->getStartColor()->setRGB('2F7E8A'); // dark teal

		$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

		$sheet->getStyle('A2')->getFont()->setSize(10)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
		
		$sheet->getStyle('A3:F4')->getFill()->setFillType(Fill::FILL_SOLID)
			->getStartColor()->setRGB('E7F3F5');

		$sheet->getStyle('A3')->getFont()
			->setBold(true)
			->setSize(13)
			->getColor()->setRGB('1F4E79');

		$sheet->getStyle('A4')->getFont()
			->setBold(true)
			->setSize(11)
			->getColor()->setRGB('404040');
		$sheet->getStyle('A3:F4')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

		// ===== HEADER STYLE =====
		$sheet->getStyle('A6:F6')->getFont()
			->setBold(true)
			->setSize(11)
			->getColor()->setRGB('FFFFFF');

		$sheet->getStyle('A6:F6')->getAlignment()
			->setHorizontal(Alignment::HORIZONTAL_CENTER);

		$sheet->getStyle('A6:F6')->getFill()->setFillType(Fill::FILL_SOLID)
			->getStartColor()->setRGB('3C5A82');
		
		$sheet->getStyle('A6:F6')->getBorders()->getBottom()
    		->setBorderStyle(Border::BORDER_MEDIUM);

		// ===== BORDER =====
		$lastRow = $rowNum - 1;
		if ($lastRow < 7) {
			$lastRow = 7;
		}
		$sheet->getStyle("A6:F{$lastRow}")
			->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);

		// ===== NUMBER FORMAT =====
		foreach (range(7, $lastRow) as $r) {
			$sheet->getStyle("B$r:F$r")->getNumberFormat()->setFormatCode('#,##0.00');
			$sheet->getStyle("B$r:F$r")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
		}
		
		for ($i = 7; $i <= $lastRow; $i++) {
			if ($i % 2 == 0) {
				$sheet->getStyle("A$i:F$i")->getFill()->setFillType(Fill::FILL_SOLID)
					->getStartColor()->setRGB('F7FBFC');
			}
		}
		
		// ===== TOTAL ROW =====
		$totalRow = $lastRow + 1;

		$sheet->setCellValue("A$totalRow", 'TOTAL');
		$sheet->setCellValue("B$totalRow", "=SUM(B7:B$lastRow)");
		$sheet->setCellValue("C$totalRow", "=SUM(C7:C$lastRow)");
		$sheet->setCellValue("D$totalRow", "=SUM(D7:D$lastRow)");
		$sheet->setCellValue("E$totalRow", "=SUM(E7:E$lastRow)");
		$sheet->setCellValue("F$totalRow", "=SUM(F7:F$lastRow)");

		$sheet->getStyle("A$totalRow:F$totalRow")->getFont()->setBold(true);
		$sheet->getStyle("A$totalRow:F$totalRow")->getFill()->setFillType(Fill::FILL_SOLID)
			->getStartColor()->setRGB('D9E1F2');
		
		$sheet->getStyle("A$totalRow:F$totalRow")->getBorders()->getTop()
    		->setBorderStyle(Border::BORDER_MEDIUM);
		
		$sheet->getStyle("B$totalRow:F$totalRow")
    		->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);

		// ===== DOWNLOAD =====
		$fileName = 'profit_loss_report_' . date('d-m-Y_H-i') . '.xlsx';

		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header("Content-Disposition: attachment;filename=\"$fileName\"");
		header('Cache-Control: max-age=0');

		$writer = new Xlsx($spreadsheet);
		$writer->save('php://output');
		exit;
	}
	
	public function profitLossPdf()
	{
		$db        = \Config\Database::connect();
		$projectId = $this->request->getGet('project_id');
		$startDate = $this->request->getGet('start_date');
		$endDate   = $this->request->getGet('end_date');

		$dateFilterSale = "";
		$dateFilterPurch = "";
		$dateFilterExp = "";

		if ($startDate) {
			$dateFilterSale  .= " AND s.sale_date >= '$startDate'";
			$dateFilterPurch .= " AND pu.purchase_date >= '$startDate'";
			$dateFilterExp   .= " AND e.expense_date >= '$startDate'";
		}
		if ($endDate) {
			$dateFilterSale  .= " AND s.sale_date <= '$endDate'";
			$dateFilterPurch .= " AND pu.purchase_date <= '$endDate'";
			$dateFilterExp   .= " AND e.expense_date <= '$endDate'";
		}

		$rows = $db->query("
			SELECT pr.id, pr.name AS project_name,
				COALESCE(SUM(DISTINCT s.total_amount),0) AS revenue,
				COALESCE(SUM(DISTINCT e.amount),0) AS expenses
			FROM projects pr
			LEFT JOIN sales s ON s.project_id = pr.id
			LEFT JOIN expenses e ON e.project_id = pr.id
			WHERE 1=1
			" . ($projectId ? " AND pr.id = $projectId" : "") . "
			$dateFilterSale
			$dateFilterExp
			GROUP BY pr.id, pr.name
			ORDER BY revenue DESC
		")->getResultArray();

		// Release 1.6B (Approved Design Decision 5): COGS is allocation-aware —
		// only the project_qty portion of each purchase line, not the full
		// supplier invoice.
		$costByProject = (new ProjectModel())->getAllocatedPurchaseCostByProject($projectId ?: null, $startDate ?: null, $endDate ?: null);
		foreach ($rows as &$r) {
			$r['cogs'] = $costByProject[(int) $r['id']] ?? 0.0;
		}
		unset($r);

		// ===== PROJECT NAME =====
		$projectName = 'All Projects';
		if ($projectId) {
			$projectName = $db->query("SELECT name FROM projects WHERE id = $projectId")->getRow()->name ?? '';
		}

		// ===== HTML =====
		$html = '
			<style>
				body {
					font-family: DejaVu Sans;
					font-size: 11px;
					color: #2d3748;
				}

				.header-box {
					background: #2F7E8A;
					color: #fff;
					padding: 12px;
					border-radius: 6px;
					text-align: center;
					margin-bottom: 10px;
				}

				.header-box h2 {
					margin: 0;
					font-size: 16px;
					letter-spacing: 1px;
				}

				.meta {
					text-align: center;
					font-size: 10px;
					margin-top: 4px;
					color: #e2e8f0;
				}

				.project-text {
					display:block;
					margin-top:5px;
					color:#ffffff;
					font-weight:bold;
				}

				.period-text {
					display:block;
					margin-top:2px;
					font-size:10px;
					color:#e2e8f0;
				}

				table {
					width: 100%;
					border-collapse: collapse;
					margin-top: 8px;
				}

				th {
					background: #3C5A82;
					color: #fff;
					padding: 7px;
					font-size: 11px;
				}

				td {
					padding: 6px;
					border: 1px solid #e2e8f0;
				}

				tr:nth-child(even) td {
					background: #f8fafc;
				}

				.project-row {
					font-weight: bold;
					color: #2F7E8A;
				}

				.right { text-align:right; }

				.profit {
					color:#2e7d32;
					font-weight:bold;
				}

				.loss {
					color:#c62828;
					font-weight:bold;
				}

				.total {
					background:#edf2f7;
					font-weight:bold;
					font-size:12px;
				}

				.footer-note {
					margin-top:10px;
					font-size:9px;
					text-align:right;
					color:#888;
				}
			</style>

			<div class="header-box">
				<h2>PROFIT & LOSS REPORT</h2>
				<div class="meta">
					Generated On: '.date('d-m-Y h:i A').'
					<span class="project-text">Project: '.$projectName.'</span>
					<span class="period-text">Period: '.($startDate ?: 'Start').' to '.($endDate ?: 'End').'</span>
				</div>
			</div>

		<table>
			<tr>
				<th>Project</th>
				<th>Revenue</th>
				<th>COGS</th>
				<th>Gross Profit</th>
				<th>Expenses</th>
				<th>Net Profit</th>
			</tr>
		';

		$totalRev = $totalCogs = $totalExp = 0;

		foreach ($rows as $r) {
			$gross = $r['revenue'] - $r['cogs'];
			$net   = $gross - $r['expenses'];

			$totalRev += $r['revenue'];
			$totalCogs += $r['cogs'];
			$totalExp += $r['expenses'];

			$html .= '
			<tr>
				<td class="project-row">'.$r['project_name'].'</td>
				<td class="right">'.number_format($r['revenue'],2).'</td>
				<td class="right">'.number_format($r['cogs'],2).'</td>
				<td class="right">'.number_format($gross,2).'</td>
				<td class="right">'.number_format($r['expenses'],2).'</td>
				<td class="right">'.number_format($net,2).'</td>
			</tr>';
		}

		$grossTotal = $totalRev - $totalCogs;
		$netTotal   = $grossTotal - $totalExp;

		$html .= '
			<tr class="total">
				<td>TOTAL</td>
				<td class="right">'.number_format($totalRev,2).'</td>
				<td class="right">'.number_format($totalCogs,2).'</td>
				<td class="right">'.number_format($grossTotal,2).'</td>
				<td class="right">'.number_format($totalExp,2).'</td>
				<td class="right">'.number_format($netTotal,2).'</td>
			</tr>
		</table>';

		// ===== DOMPDF =====
		$options = new Options();
		$options->set('isRemoteEnabled', true);

		$dompdf = new Dompdf($options);
		$dompdf->loadHtml($html);
		$dompdf->setPaper('A4', 'portrait');
		$dompdf->render();

		$fileName = 'profit_loss_report_' . date('d-m-Y_H-i') . '.pdf';

		$dompdf->stream($fileName, ["Attachment" => true]);
	}

    public function stock()
	{
		$db = \Config\Database::connect();

		$productId = $this->request->getGet('product_id');
		$productId = ($productId === 'all' || $productId === '' || $productId === null) ? null : (int)$productId;

		$whereProduct = ($productId !== null) ? " AND p.id = $productId" : "";

		$data['stock'] = $db->query("
			SELECT
				p.id, p.name, p.unit,
				COALESCE(SUM(CASE WHEN sl.source='GENERAL' AND sl.transaction_type='IN' THEN sl.quantity ELSE 0 END),0)
				- COALESCE(SUM(CASE WHEN sl.source='GENERAL' AND sl.transaction_type='OUT' THEN sl.quantity ELSE 0 END),0) AS general_stock,
				COALESCE(SUM(CASE WHEN sl.source='PROJECT' AND sl.transaction_type='IN' THEN sl.quantity ELSE 0 END),0)
				- COALESCE(SUM(CASE WHEN sl.source='PROJECT' AND sl.transaction_type='OUT' THEN sl.quantity ELSE 0 END),0) AS project_stock
			FROM products p
			LEFT JOIN stock_ledger sl ON sl.product_id = p.id
			WHERE 1=1 $whereProduct
			GROUP BY p.id, p.name, p.unit
			ORDER BY p.name DESC
		")->getResultArray();

		$data['products']   = $db->query("SELECT id,name FROM products ORDER BY name ASC")->getResultArray();
		$data['product_id'] = $productId;

		return view('reports/stock', $data);
	}
	
	public function stockExport()
	{
		$db = \Config\Database::connect();

		$productId = $this->request->getGet('product_id');
		$productId = ($productId === 'all' || $productId === '') ? null : $productId;
		$whereProduct = $productId ? " AND p.id = $productId" : "";

		$rows = $db->query("
			SELECT
				p.name, p.unit,
				COALESCE(SUM(CASE WHEN sl.source='GENERAL' AND sl.transaction_type='IN' THEN sl.quantity ELSE 0 END),0)
				- COALESCE(SUM(CASE WHEN sl.source='GENERAL' AND sl.transaction_type='OUT' THEN sl.quantity ELSE 0 END),0) AS general_stock,
				COALESCE(SUM(CASE WHEN sl.source='PROJECT' AND sl.transaction_type='IN' THEN sl.quantity ELSE 0 END),0)
				- COALESCE(SUM(CASE WHEN sl.source='PROJECT' AND sl.transaction_type='OUT' THEN sl.quantity ELSE 0 END),0) AS project_stock
			FROM products p
			LEFT JOIN stock_ledger sl ON sl.product_id = p.id
			WHERE 1=1 $whereProduct
			GROUP BY p.id, p.name, p.unit
			ORDER BY p.name ASC
		")->getResultArray();

		// ===== EXCEL =====
		$spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();
		
		$sheet->freezePane('A5');

		$sheet->mergeCells('A1:E1');
		$sheet->setCellValue('A1', 'STOCK REPORT');

		$sheet->mergeCells('A2:E2');
		$sheet->setCellValue('A2', 'Generated On: ' . date('d-m-Y h:i A'));
		
		$sheet->getStyle('A1:E2')->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
			->getStartColor()->setRGB('2F7E8A');

		$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A1')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		$sheet->getStyle('A2')->getFont()->setSize(10)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A2')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		// HEADER
		$sheet->setCellValue('A4', 'Product');
		$sheet->setCellValue('B4', 'Unit');
		$sheet->setCellValue('C4', 'General Stock');
		$sheet->setCellValue('D4', 'Project Stock');
		$sheet->setCellValue('E4', 'Total');
		
		$sheet->getStyle('A4:E4')->getFont()
			->setBold(true)
			->setSize(11)
			->getColor()->setRGB('FFFFFF');

		$sheet->getStyle('A4:E4')->getAlignment()
			->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		$sheet->getStyle('A4:E4')->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
			->getStartColor()->setRGB('3C5A82');

		$sheet->getStyle('A4:E4')->getBorders()->getBottom()
			->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_MEDIUM);

		$rowNum = 5;

		foreach ($rows as $r) {
			$total = $r['general_stock'] + $r['project_stock'];

			$sheet->setCellValue('A'.$rowNum, $r['name']);
			$sheet->setCellValue('B'.$rowNum, $r['unit']);
			$sheet->setCellValue('C'.$rowNum, $r['general_stock']);
			$sheet->setCellValue('D'.$rowNum, $r['project_stock']);
			$sheet->setCellValue('E'.$rowNum, $total);

			$rowNum++;
		}
		
		$lastRow = $rowNum - 1;
		
		if ($lastRow < 5) {
			$lastRow = 5;
		}

		$sheet->getStyle("A4:E{$lastRow}")
			->getBorders()->getAllBorders()
			->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

		for ($i = 5; $i <= $lastRow; $i++) {
			$sheet->getStyle("C$i:E$i")->getNumberFormat()->setFormatCode('#,##0');
			$sheet->getStyle("C$i:E$i")->getAlignment()
				->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
			$sheet->getStyle("B$i")->getAlignment()
				->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
			$sheet->getStyle("A$i")->getFont()->setBold(true);
			
			// ===== STOCK HIGHLIGHT =====
			$total = $sheet->getCell("E$i")->getValue();

			if ($total < 0) {
				$sheet->getStyle("E$i")->getFont()->getColor()->setRGB('9C6500');
				$sheet->getStyle("E$i")->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
					->getStartColor()->setRGB('FCE4D6');
			}
			elseif ($total == 0) {
				$sheet->getStyle("E$i")->getFont()->getColor()->setRGB('C00000');
				$sheet->getStyle("E$i")->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
					->getStartColor()->setRGB('FFF2CC');
			}
			else {
				$sheet->getStyle("E$i")->getFont()->getColor()->setRGB('006100');
			}
		}
		
		for ($i = 5; $i <= $lastRow; $i++) {
			if ($i % 2 == 0) {
				$sheet->getStyle("A$i:E$i")->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
					->getStartColor()->setRGB('F7FBFC');
			}
		}
		
		$totalRow = $lastRow + 1;

		$sheet->setCellValue("A$totalRow", 'TOTAL');
		$sheet->getStyle("A$totalRow")->getAlignment()
    		->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
		$sheet->setCellValue("C$totalRow", "=SUM(C5:C$lastRow)");
		$sheet->setCellValue("D$totalRow", "=SUM(D5:D$lastRow)");
		$sheet->setCellValue("E$totalRow", "=SUM(E5:E$lastRow)");

		$sheet->getStyle("A$totalRow:E$totalRow")->getFont()->setBold(true);
		$sheet->getStyle("A$totalRow:E$totalRow")->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
			->getStartColor()->setRGB('D9E1F2');

		$sheet->getStyle("A$totalRow:E$totalRow")->getBorders()->getTop()
			->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_MEDIUM);
		
		$sheet->getStyle("C$totalRow:E$totalRow")
    		->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		foreach (range('A','E') as $col) {
			$sheet->getColumnDimension($col)->setAutoSize(true);
		}

		$fileName = 'stock_report_' . date('d-m-Y_H-i') . '.xlsx';

		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header("Content-Disposition: attachment;filename=\"$fileName\"");

		$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
		$writer->save('php://output');
		exit;
	}
	
	public function stockPdf()
	{
		$db = \Config\Database::connect();

		$productId = $this->request->getGet('product_id');
		$whereProduct = $productId ? " AND p.id = $productId" : "";

		$rows = $db->query("
			SELECT
				p.name, p.unit,
				COALESCE(SUM(CASE WHEN sl.source='GENERAL' AND sl.transaction_type='IN' THEN sl.quantity ELSE 0 END),0)
				- COALESCE(SUM(CASE WHEN sl.source='GENERAL' AND sl.transaction_type='OUT' THEN sl.quantity ELSE 0 END),0) AS general_stock,
				COALESCE(SUM(CASE WHEN sl.source='PROJECT' AND sl.transaction_type='IN' THEN sl.quantity ELSE 0 END),0)
				- COALESCE(SUM(CASE WHEN sl.source='PROJECT' AND sl.transaction_type='OUT' THEN sl.quantity ELSE 0 END),0) AS project_stock
			FROM products p
			LEFT JOIN stock_ledger sl ON sl.product_id = p.id
			WHERE 1=1 $whereProduct
			GROUP BY p.id, p.name, p.unit
			ORDER BY p.name ASC
		")->getResultArray();

		// ===== HTML =====
		$html = '
			<style>
				body {
					font-family: DejaVu Sans;
					font-size: 11px;
					color: #2d3748;
				}

				.header-box {
					background: #2F7E8A;
					color: #fff;
					padding: 12px;
					border-radius: 6px;
					text-align: center;
					margin-bottom: 10px;
				}

				.header-box h2 {
					margin: 0;
					font-size: 16px;
					letter-spacing: 1px;
				}

				.meta {
					text-align: center;
					font-size: 10px;
					margin-top: 4px;
					color: #e2e8f0;
				}

				table {
					width: 100%;
					border-collapse: collapse;
					margin-top: 8px;
				}

				th {
					background: #3C5A82;
					color: #fff;
					padding: 7px;
					font-size: 11px;
				}

				td {
					padding: 6px;
					border: 1px solid #e2e8f0;
				}

				tr:nth-child(even) td {
					background: #f8fafc;
				}

				.center { text-align: center; }
				.right { text-align: right; }

				.total-row {
					background: #edf2f7;
					font-weight: bold;
					font-size: 12px;
				}

				.negative { color: #c62828; font-weight: bold; }
				.zero { color: #c62828; font-weight: bold; }
				.positive { color: #2e7d32; font-weight: bold; }

				.footer-note {
					margin-top: 10px;
					font-size: 9px;
					text-align: right;
					color: #888;
				}
			</style>

			<div class="header-box">
				<h2>STOCK REPORT</h2>
				<div class="meta">
					Generated On: '.date('d-m-Y h:i A').'
				</div>
			</div>

		<table>
			<tr>
				<th>Product</th>
				<th>Unit</th>
				<th>General</th>
				<th>Project</th>
				<th>Total</th>
			</tr>
		';

		$totalGen = $totalProj = 0;

		foreach ($rows as $r) {
			$total = $r['general_stock'] + $r['project_stock'];

			$class = $total < 0 ? 'negative' : ($total == 0 ? 'zero' : 'positive');

			$html .= '
			<tr>
				<td><strong>'.$r['name'].'</strong></td>
				<td class="center">'.$r['unit'].'</td>
				<td class="center">'.number_format($r['general_stock']).'</td>
				<td class="center">'.number_format($r['project_stock']).'</td>
				<td class="center '.$class.'">'.number_format($total).'</td>
			</tr>';

			$totalGen += $r['general_stock'];
			$totalProj += $r['project_stock'];
		}

		$grand = $totalGen + $totalProj;

		$html .= '
			<tr class="total-row">
				<td>TOTAL</td>
				<td></td>
				<td class="center">'.number_format($totalGen).'</td>
				<td class="center">'.number_format($totalProj).'</td>
				<td class="center">'.number_format($grand).'</td>
			</tr>
		</table>';

		// ===== DOMPDF =====
		$options = new \Dompdf\Options();
		$options->set('isRemoteEnabled', true);

		$dompdf = new \Dompdf\Dompdf($options);
		$dompdf->loadHtml($html);
		$dompdf->setPaper('A4', 'portrait');
		$dompdf->render();

		$fileName = 'stock_report_' . date('d-m-Y_H-i') . '.pdf';

		$dompdf->stream($fileName, ["Attachment" => true]);
	}

    public function sales()
	{
		$db = \Config\Database::connect();

		$projectId  = $this->request->getGet('project_id');
		$customerId = $this->request->getGet('customer_id');
		$status     = $this->request->getGet('status');

		$where = "WHERE 1=1";

		if (!empty($projectId)) {
			$where .= " AND s.project_id = $projectId";
		}

		if (!empty($customerId)) {
			$where .= " AND s.customer_id = $customerId";
		}

		if (!empty($status)) {
			$where .= " AND s.status = '$status'";
		}

		$data['sales'] = $db->query("
			SELECT s.*, p.name AS project_name, c.name AS customer_name
			FROM sales s
			LEFT JOIN projects p ON s.project_id = p.id
			LEFT JOIN customers c ON s.customer_id = c.id
			$where
			ORDER BY s.sale_date DESC
		")->getResultArray();

		// dropdown data
		$data['projects']  = $db->query("SELECT id,name FROM projects ORDER BY name ASC")->getResultArray();
		$data['customers'] = $db->query("SELECT id,name FROM customers ORDER BY name ASC")->getResultArray();

		// keep selected
		$data['project_id']  = $projectId;
		$data['customer_id'] = $customerId;
		$data['status']      = $status;

		return view('reports/sales', $data);
	}
	
	public function salesExport()
	{
		$db = \Config\Database::connect();

		$projectId  = $this->request->getGet('project_id');
		$customerId = $this->request->getGet('customer_id');
		$status     = $this->request->getGet('status');

		$where = "WHERE 1=1";

		if (!empty($projectId)) {
			$where .= " AND s.project_id = $projectId";
		}

		if (!empty($customerId)) {
			$where .= " AND s.customer_id = $customerId";
		}

		if (!empty($status)) {
			$where .= " AND s.status = '$status'";
		}

		$rows = $db->query("
			SELECT s.*, p.name AS project_name, c.name AS customer_name
			FROM sales s
			LEFT JOIN projects p ON s.project_id = p.id
			LEFT JOIN customers c ON s.customer_id = c.id
			$where
			ORDER BY s.sale_date DESC
		")->getResultArray();

		// ===== EXCEL =====
		$spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();

		$sheet->freezePane('A7');

		// ===== TITLE =====
		$sheet->mergeCells('A1:J1');
		$sheet->setCellValue('A1', 'SALES REPORT');

		$sheet->mergeCells('A2:J2');
		$sheet->setCellValue('A2', 'Generated On: ' . date('d-m-Y h:i A'));

		// ===== PROJECT =====
		$projectName = 'All Projects';
		if (!empty($projectId)) {
			$projectName = $db->query("SELECT name FROM projects WHERE id = ?", [$projectId])->getRow()->name ?? '';
		}

		$sheet->mergeCells('A3:J3');
		$sheet->setCellValue('A3', 'Project: ' . $projectName);

		// ===== HEADER STYLE =====
		$sheet->getStyle('A1:J3')->getFill()
			->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
			->getStartColor()->setRGB('2F7E8A');

		$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A1')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		$sheet->getStyle('A2')->getFont()->setSize(10)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A2')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		$sheet->getStyle('A3')->getFont()->setBold(true)->setSize(11)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A3')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		// ===== TABLE HEADER =====
		$sheet->setCellValue('A6', '#');
		$sheet->setCellValue('B6', 'Invoice');
		$sheet->setCellValue('C6', 'Project');
		$sheet->setCellValue('D6', 'Customer');
		$sheet->setCellValue('E6', 'Source');
		$sheet->setCellValue('F6', 'Date');
		$sheet->setCellValue('G6', 'Total');
		$sheet->setCellValue('H6', 'Paid');
		$sheet->setCellValue('I6', 'Balance');
		$sheet->setCellValue('J6', 'Status');

		$sheet->getStyle('A6:J6')->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A6:J6')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		$sheet->getStyle('A6:J6')->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
			->getStartColor()->setRGB('3C5A82');

		// ===== DATA =====
		$rowNum = 7;
		$i = 1;

		$total = $paid = $balance = 0;

		foreach ($rows as $r) {

			$sheet->setCellValue('A'.$rowNum, $i++);
			$sheet->setCellValue('B'.$rowNum, $r['invoice_no']);
			$sheet->setCellValue('C'.$rowNum, $r['project_name']);
			$sheet->setCellValue('D'.$rowNum, $r['customer_name']);
			$sheet->setCellValue('E'.$rowNum, $r['stock_source']);
			$sheet->setCellValue('F'.$rowNum, $r['sale_date']);
			$sheet->setCellValue('G'.$rowNum, $r['total_amount']);
			$sheet->setCellValue('H'.$rowNum, $r['paid_amount']);
			$sheet->setCellValue('I'.$rowNum, $r['balance_amount']);
			$sheet->setCellValue('J'.$rowNum, $r['status']);

			$total += $r['total_amount'];
			$paid += $r['paid_amount'];
			$balance += $r['balance_amount'];

			$rowNum++;
		}

		$lastRow = $rowNum - 1;

		// ===== TOTAL ROW =====
		$totalRow = $lastRow + 1;

		$sheet->setCellValue("A$totalRow", 'TOTAL');
		$sheet->mergeCells("A$totalRow:F$totalRow");

		$sheet->setCellValue("G$totalRow", $total);
		$sheet->setCellValue("H$totalRow", $paid);
		$sheet->setCellValue("I$totalRow", $balance);

		$sheet->getStyle("A$totalRow:J$totalRow")->getFont()->setBold(true);
		$sheet->getStyle("A$totalRow:J$totalRow")->getFill()
			->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
			->getStartColor()->setRGB('D9E1F2');

		// ===== BORDER =====
		$sheet->getStyle("A6:J{$totalRow}")
			->getBorders()->getAllBorders()
			->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

		// ===== ZEBRA =====
		for ($r = 7; $r <= $lastRow; $r++) {
			if ($r % 2 == 0) {
				$sheet->getStyle("A$r:J$r")->getFill()
					->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
					->getStartColor()->setRGB('F7FBFC');
			}
		}

		// ===== ALIGN =====
		$sheet->getStyle("G7:I{$totalRow}")
			->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT);

		foreach (range('A','J') as $col) {
			$sheet->getColumnDimension($col)->setAutoSize(true);
		}

		$fileName = 'sales_report_' . date('d-m-Y_H-i') . '.xlsx';

		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header("Content-Disposition: attachment;filename=\"$fileName\"");

		$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
		$writer->save('php://output');
		exit;
	}
	
	public function salesPdf()
	{
		$db = \Config\Database::connect();

		$projectId  = $this->request->getGet('project_id');
		$customerId = $this->request->getGet('customer_id');
		$status     = $this->request->getGet('status');

		$where = "WHERE 1=1";

		if (!empty($projectId)) {
			$where .= " AND s.project_id = $projectId";
		}

		if (!empty($customerId)) {
			$where .= " AND s.customer_id = $customerId";
		}

		if (!empty($status)) {
			$where .= " AND s.status = '$status'";
		}

		$rows = $db->query("
			SELECT s.*, p.name AS project_name, c.name AS customer_name
			FROM sales s
			LEFT JOIN projects p ON s.project_id = p.id
			LEFT JOIN customers c ON s.customer_id = c.id
			$where
			ORDER BY s.sale_date DESC
		")->getResultArray();

		// ===== PROJECT NAME =====
		$projectName = 'All Projects';
		if (!empty($projectId)) {
			$projectName = $db->query("SELECT name FROM projects WHERE id = ?", [$projectId])->getRow()->name ?? '';
		}

		// ===== HTML =====
		$html = '
			<style>
				body {
					font-family: DejaVu Sans;
					font-size: 11px;
					color: #2d3748;
				}

				.header-box {
					background: #2F7E8A;
					color: #fff;
					padding: 12px;
					border-radius: 6px;
					text-align: center;
					margin-bottom: 10px;
				}

				.header-box h2 {
					margin: 0;
					font-size: 16px;
					letter-spacing: 1px;
				}

				.meta {
					text-align: center;
					font-size: 10px;
					margin-top: 4px;
					color: #e2e8f0;
				}

				.project {
					text-align: center;
					font-size: 11px;
					font-weight: bold;
					color: #2F7E8A;
					margin: 10px 0;
				}

				table {
					width: 100%;
					border-collapse: collapse;
					margin-top: 5px;
				}

				th {
					background: #3C5A82;
					color: #fff;
					padding: 7px;
					font-size: 11px;
					letter-spacing: 0.5px;
				}

				td {
					padding: 6px;
					border: 1px solid #e2e8f0;
				}

				tr:nth-child(even) td {
					background: #f8fafc;
				}

				.right { text-align: right; }
				.center { text-align: center; }

				.paid { color: #2e7d32; font-weight: bold; }
				.pending { color: #c62828; font-weight: bold; }
				.partial { color: #ef6c00; font-weight: bold; }

				.total-row {
					background: #edf2f7;
					font-weight: bold;
					font-size: 12px;
				}

				.footer-note {
					margin-top: 10px;
					font-size: 9px;
					text-align: right;
					color: #888;
				}
			</style>

			<div class="header-box">
				<h2>SALES REPORT</h2>
				<div class="meta">
					Generated On: '.date('d-m-Y h:i A').'
				</div>
			</div>

			<div class="project">
				Project: '.$projectName.'
			</div>

		<table>
			<tr>
				<th>#</th>
				<th>Invoice</th>
				<th>Project</th>
				<th>Customer</th>
				<th>Source</th>
				<th>Date</th>
				<th>Total</th>
				<th>Paid</th>
				<th>Balance</th>
				<th>Status</th>
			</tr>
		';

		$i = 1;
		$grandTotal = $grandPaid = $grandBalance = 0;

		foreach ($rows as $r) {

			$statusClass = strtolower($r['status']);

			$grandTotal += $r['total_amount'];
			$grandPaid  += $r['paid_amount'];
			$grandBalance += $r['balance_amount'];

			$html .= '
			<tr>
				<td class="center">'.$i++.'</td>
				<td>'.$r['invoice_no'].'</td>
				<td>'.$r['project_name'].'</td>
				<td>'.$r['customer_name'].'</td>
				<td class="center">'.$r['stock_source'].'</td>
				<td>'.$r['sale_date'].'</td>
				<td class="right">'.number_format($r['total_amount'],2).'</td>
				<td class="right">'.number_format($r['paid_amount'],2).'</td>
				<td class="right">'.number_format($r['balance_amount'],2).'</td>
				<td class="center '.$statusClass.'">'.$r['status'].'</td>
			</tr>';
		}

		// ===== TOTAL =====
		$html .= '
			<tr class="total-row">
				<td colspan="6">TOTAL</td>
				<td class="right">'.number_format($grandTotal,2).'</td>
				<td class="right">'.number_format($grandPaid,2).'</td>
				<td class="right">'.number_format($grandBalance,2).'</td>
				<td></td>
			</tr>
		</table>';

		// ===== DOMPDF =====
		$options = new \Dompdf\Options();
		$options->set('isRemoteEnabled', true);

		$dompdf = new \Dompdf\Dompdf($options);
		$dompdf->loadHtml($html);
		$dompdf->setPaper('A4', 'landscape'); // better fit
		$dompdf->render();

		$fileName = 'sales_report_' . date('d-m-Y_H-i') . '.pdf';

		$dompdf->stream($fileName, ["Attachment" => true]);
	}

    public function purchases()
	{
		$db = \Config\Database::connect();

		$projectId  = $this->request->getGet('project_id');
		$supplierId = $this->request->getGet('supplier_id');

		$where = "WHERE 1=1";

		if (!empty($projectId)) {
			$where .= " AND pu.project_id = $projectId";
		}

		if (!empty($supplierId)) {
			$where .= " AND pu.supplier_id = $supplierId";
		}

		$data['purchases'] = $db->query("
			SELECT pu.*, s.name AS supplier_name, p.name AS project_name
			FROM purchases pu
			LEFT JOIN suppliers s ON pu.supplier_id = s.id
			LEFT JOIN projects p ON pu.project_id = p.id
			$where
			ORDER BY pu.purchase_date DESC
		")->getResultArray();

		// dropdowns
		$data['projects']  = $db->query("SELECT id,name FROM projects ORDER BY name ASC")->getResultArray();
		$data['suppliers'] = $db->query("SELECT id,name FROM suppliers ORDER BY name ASC")->getResultArray();

		// selected values
		$data['project_id']  = $projectId;
		$data['supplier_id'] = $supplierId;

		return view('reports/purchases', $data);
	}
	
	public function purchasesExport()
	{
		$db = \Config\Database::connect();

		$projectId  = $this->request->getGet('project_id');
		$supplierId = $this->request->getGet('supplier_id');

		$where = "WHERE 1=1";

		if (!empty($projectId)) {
			$where .= " AND pu.project_id = $projectId";
		}

		if (!empty($supplierId)) {
			$where .= " AND pu.supplier_id = $supplierId";
		}

		$rows = $db->query("
			SELECT pu.*, s.name AS supplier_name, p.name AS project_name
			FROM purchases pu
			LEFT JOIN suppliers s ON pu.supplier_id = s.id
			LEFT JOIN projects p ON pu.project_id = p.id
			$where
			ORDER BY pu.purchase_date DESC
		")->getResultArray();

		// ===== PROJECT NAME =====
		$projectName = 'All Projects';
		if (!empty($projectId)) {
			$projectName = $db->query("SELECT name FROM projects WHERE id = ?", [$projectId])->getRow()->name ?? '';
		}

		// ===== EXCEL =====
		$spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();

		$sheet->freezePane('A6');

		// ===== TITLE =====
		$sheet->mergeCells('A1:G1');
		$sheet->setCellValue('A1', 'PURCHASE REPORT');

		$sheet->mergeCells('A2:G2');
		$sheet->setCellValue('A2', 'Generated On: ' . date('d-m-Y h:i A'));

		$sheet->mergeCells('A3:G3');
		$sheet->setCellValue('A3', 'Project: ' . $projectName);

		// ===== HEADER STYLE =====
		$sheet->getStyle('A1:G3')->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
			->getStartColor()->setRGB('2F7E8A');

		$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A1')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		$sheet->getStyle('A2:A3')->getFont()->setSize(10)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A2:A3')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		// ===== TABLE HEADER =====
		$sheet->setCellValue('A5', '#');
		$sheet->setCellValue('B5', 'Invoice');
		$sheet->setCellValue('C5', 'Supplier');
		$sheet->setCellValue('D5', 'Project');
		$sheet->setCellValue('E5', 'Source');
		$sheet->setCellValue('F5', 'Date');
		$sheet->setCellValue('G5', 'Total');

		$sheet->getStyle('A5:G5')->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A5:G5')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		$sheet->getStyle('A5:G5')->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
			->getStartColor()->setRGB('3C5A82');

		// ===== DATA =====
		$rowNum = 6;
		$i = 1;
		$grand = 0;

		foreach ($rows as $r) {

			$grand += $r['total_amount'];

			$sheet->setCellValue('A'.$rowNum, $i++);
			$sheet->setCellValue('B'.$rowNum, $r['invoice_no']);
			$sheet->setCellValue('C'.$rowNum, $r['supplier_name']);
			$sheet->setCellValue('D'.$rowNum, $r['project_name']);
			$sheet->setCellValue('E'.$rowNum, 'PROJECT');
			$sheet->setCellValue('F'.$rowNum, $r['purchase_date']);
			$sheet->setCellValue('G'.$rowNum, $r['total_amount']);

			// ALIGN
			$sheet->getStyle('A'.$rowNum.':F'.$rowNum)
				->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

			$sheet->getStyle('G'.$rowNum)
				->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT);

			$rowNum++;
		}

		$lastRow = $rowNum - 1;

		// ===== TOTAL =====
		$totalRow = $lastRow + 1;

		$sheet->setCellValue("A$totalRow", 'TOTAL');
		$sheet->mergeCells("A$totalRow:F$totalRow");
		$sheet->setCellValue("G$totalRow", $grand);

		$sheet->getStyle("A$totalRow:G$totalRow")->getFont()->setBold(true);
		$sheet->getStyle("A$totalRow:G$totalRow")->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
			->getStartColor()->setRGB('D9E1F2');

		// ===== BORDER =====
		$sheet->getStyle("A5:G{$lastRow}")
			->getBorders()->getAllBorders()
			->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

		// ===== ZEBRA =====
		for ($r = 6; $r <= $lastRow; $r++) {
			if ($r % 2 == 0) {
				$sheet->getStyle("A$r:G$r")->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
					->getStartColor()->setRGB('F7FBFC');
			}
		}

		// ===== AUTO SIZE =====
		foreach (range('A','G') as $col) {
			$sheet->getColumnDimension($col)->setAutoSize(true);
		}

		// ===== DOWNLOAD =====
		$fileName = 'purchase_report_' . date('d-m-Y_H-i') . '.xlsx';

		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header("Content-Disposition: attachment;filename=\"$fileName\"");

		$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
		$writer->save('php://output');
		exit;
	}
	
	public function purchasesPdf()
	{
		$db = \Config\Database::connect();

		$projectId  = $this->request->getGet('project_id');
		$supplierId = $this->request->getGet('supplier_id');

		$where = "WHERE 1=1";

		if (!empty($projectId)) {
			$where .= " AND pu.project_id = $projectId";
		}

		if (!empty($supplierId)) {
			$where .= " AND pu.supplier_id = $supplierId";
		}

		$rows = $db->query("
			SELECT pu.*, s.name AS supplier_name, p.name AS project_name
			FROM purchases pu
			LEFT JOIN suppliers s ON pu.supplier_id = s.id
			LEFT JOIN projects p ON pu.project_id = p.id
			$where
			ORDER BY pu.purchase_date DESC
		")->getResultArray();

		// ===== PROJECT NAME =====
		$projectName = 'All Projects';
		if (!empty($projectId)) {
			$projectName = $db->query("SELECT name FROM projects WHERE id = ?", [$projectId])->getRow()->name ?? '';
		}

		// ===== HTML =====
		$html = '
			<style>
				body {
					font-family: DejaVu Sans;
					font-size: 11px;
					color: #2d3748;
				}

				.header-box {
					background: #2F7E8A;
					color: #fff;
					padding: 12px;
					border-radius: 6px;
					text-align: center;
					margin-bottom: 10px;
				}

				.header-box h2 {
					margin: 0;
					font-size: 16px;
					letter-spacing: 1px;
				}

				.meta {
					text-align: center;
					font-size: 10px;
					margin-top: 4px;
					color: #e2e8f0;
				}

				.project {
					text-align: center;
					font-size: 11px;
					font-weight: bold;
					color: #2F7E8A;
					margin: 10px 0;
				}

				table {
					width: 100%;
					border-collapse: collapse;
					margin-top: 5px;
				}

				th {
					background: #3C5A82;
					color: #fff;
					padding: 7px;
					font-size: 11px;
					letter-spacing: 0.5px;
				}

				td {
					padding: 6px;
					border: 1px solid #e2e8f0;
				}

				tr:nth-child(even) td {
					background: #f8fafc;
				}

				.right { text-align: right; }
				.center { text-align: center; }

				.total-row {
					background: #edf2f7;
					font-weight: bold;
					font-size: 12px;
				}

				.footer-note {
					margin-top: 10px;
					font-size: 9px;
					text-align: right;
					color: #888;
				}
			</style>

			<div class="header-box">
				<h2>PURCHASE REPORT</h2>
				<div class="meta">
					Generated On: '.date('d-m-Y h:i A').'
				</div>
			</div>

			<div class="project">
				Project: '.$projectName.'
			</div>';

		$html .= '

		<table>
			<tr>
				<th>#</th>
				<th>Invoice</th>
				<th>Supplier</th>
				<th>Project</th>
				<th>Source</th>
				<th>Date</th>
				<th>Total</th>
			</tr>
		';

		$i = 1;
		$grand = 0;

		foreach ($rows as $r) {

			$grand += $r['total_amount'];

			$html .= '
			<tr>
				<td class="center">'.$i++.'</td>
				<td>'.$r['invoice_no'].'</td>
				<td>'.$r['supplier_name'].'</td>
				<td>'.$r['project_name'].'</td>
				<td class="center">PROJECT</td>
				<td>'.$r['purchase_date'].'</td>
				<td class="right">'.number_format($r['total_amount'],2).'</td>
			</tr>';
		}

		// ===== TOTAL =====
		$html .= '
			<tr class="total-row">
				<td colspan="6">TOTAL</td>
				<td class="right">'.number_format($grand,2).'</td>
			</tr>
		</table>';

		// ===== DOMPDF =====
		$options = new \Dompdf\Options();
		$options->set('isRemoteEnabled', true);

		$dompdf = new \Dompdf\Dompdf($options);
		$dompdf->loadHtml($html);
		$dompdf->setPaper('A4', 'landscape'); // better layout
		$dompdf->render();

		$fileName = 'purchase_report_' . date('d-m-Y_H-i') . '.pdf';

		$dompdf->stream($fileName, ["Attachment" => true]);
	}

    public function ledger()
    {
        $db        = \Config\Database::connect();
		
        $productId = $this->request->getGet('product_id');
		$projectId = $this->request->getGet('project_id');

		$whereArr = [];

		if ($productId) {
			$whereArr[] = "sl.product_id = $productId";
		}

		if ($projectId === 'general') {
			$whereArr[] = "sl.project_id IS NULL";
		} elseif ($projectId) {
			$whereArr[] = "sl.project_id = $projectId";
		}

		$where = !empty($whereArr) ? 'WHERE ' . implode(' AND ', $whereArr) : '';
		
		$data['projects']   = $db->query("SELECT id, name FROM projects ORDER BY name ASC")->getResultArray();
		$data['project_id'] = $projectId;

        $data['ledger'] = $db->query("
            SELECT sl.*, p.name AS product_name, pr.name AS project_name
            FROM stock_ledger sl
            LEFT JOIN products p ON sl.product_id = p.id
            LEFT JOIN projects pr ON sl.project_id = pr.id
            $where
            ORDER BY sl.created_at DESC
        ")->getResultArray();

        $data['products']   = \Config\Database::connect()->query("SELECT id, name FROM products ORDER BY name ASC")->getResultArray();
        $data['product_id'] = $productId;

        return view('reports/ledger', $data);
    }
	
	public function ledgerExport()
	{
		$db = \Config\Database::connect();

		$productId = $this->request->getGet('product_id');
		$projectId = $this->request->getGet('project_id');

		// ===== FILTER FIX =====
		$productId = ($productId === '' || $productId === null) ? null : (int)$productId;

		$whereArr = [];

		if ($productId !== null) {
			$whereArr[] = "sl.product_id = $productId";
		}

		if ($projectId === 'general') {
			$whereArr[] = "sl.project_id IS NULL";
		} elseif (!empty($projectId)) {
			$whereArr[] = "sl.project_id = $projectId";
		}

		$where = !empty($whereArr) ? 'WHERE ' . implode(' AND ', $whereArr) : '';

		$rows = $db->query("
			SELECT sl.*, p.name AS product_name, pr.name AS project_name
			FROM stock_ledger sl
			LEFT JOIN products p ON sl.product_id = p.id
			LEFT JOIN projects pr ON sl.project_id = pr.id
			$where
			ORDER BY sl.created_at DESC
		")->getResultArray();

		// ===== EXCEL =====
		$spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();

		$sheet->freezePane('A7');

		// ===== TITLE =====
		$sheet->mergeCells('A1:I1');
		$sheet->setCellValue('A1', 'STOCK LEDGER REPORT');

		$sheet->mergeCells('A2:I2');
		$sheet->setCellValue('A2', 'Generated On: ' . date('d-m-Y h:i A'));

		// ===== PROJECT NAME =====
		$projectName = 'All Projects';

		if ($projectId === 'general') {
			$projectName = 'GENERAL PRODUCTS';
		} elseif (!empty($projectId)) {
			$projectName = $db->query("SELECT name FROM projects WHERE id = ?", [$projectId])
							  ->getRow()->name ?? '';
		}

		$sheet->mergeCells('A3:I3');
		$sheet->setCellValue('A3', 'Project: ' . $projectName);

		// ===== HEADER STYLE =====
		$sheet->getStyle('A1:I3')->getFill()
			->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
			->getStartColor()->setRGB('2F7E8A');

		$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A1')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		$sheet->getStyle('A2')->getFont()->setSize(10)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A2')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
		
		$sheet->getStyle('A3')->getFont()->setBold(true)->setSize(11)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A3')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		// ===== TABLE HEADER =====
		$sheet->setCellValue('A6', '#');
		$sheet->setCellValue('B6', 'Date');
		$sheet->setCellValue('C6', 'Product');
		$sheet->setCellValue('D6', 'Type');
		$sheet->setCellValue('E6', 'Qty');
		$sheet->setCellValue('F6', 'Source');
		$sheet->setCellValue('G6', 'Project');
		$sheet->setCellValue('H6', 'Reference');
		$sheet->setCellValue('I6', 'Notes');

		$sheet->getStyle('A6:I6')->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
		$sheet->getStyle('A6:I6')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

		$sheet->getStyle('A6:I6')->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
			->getStartColor()->setRGB('3C5A82');

		// ===== DATA =====
		$rowNum = 7;
		$i = 1;

		foreach ($rows as $r) {

			$sheet->setCellValue('A'.$rowNum, $i++);
			$sheet->setCellValue('B'.$rowNum, $r['transaction_date']);
			$sheet->setCellValue('C'.$rowNum, $r['product_name']);
			$sheet->setCellValue('D'.$rowNum, $r['transaction_type']);
			$sheet->setCellValue('E'.$rowNum, $r['quantity']);
			$sheet->setCellValue('F'.$rowNum, $r['source']);
			$sheet->setCellValue('G'.$rowNum, $r['project_name'] ?: '-');
			$sheet->setCellValue('H'.$rowNum, $r['reference_type'].' #'.$r['reference_id']);
			$sheet->setCellValue('I'.$rowNum, $r['notes']);

			// TYPE COLOR
			if ($r['transaction_type'] === 'IN') {
				$sheet->getStyle('D'.$rowNum)->getFont()->getColor()->setRGB('006100');
			} else {
				$sheet->getStyle('D'.$rowNum)->getFont()->getColor()->setRGB('C00000');
			}

			$rowNum++;
		}

		$lastRow = $rowNum - 1;

		// ===== BORDER =====
		$sheet->getStyle("A6:I{$lastRow}")
			->getBorders()->getAllBorders()
			->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

		// ===== ZEBRA =====
		for ($r = 7; $r <= $lastRow; $r++) {
			if ($r % 2 == 0) {
				$sheet->getStyle("A$r:I$r")->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
					->getStartColor()->setRGB('F7FBFC');
			}
		}

		// ===== AUTO SIZE =====
		foreach (range('A','I') as $col) {
			$sheet->getColumnDimension($col)->setAutoSize(true);
		}

		// ===== DOWNLOAD =====
		$fileName = 'ledger_report_' . date('d-m-Y_H-i') . '.xlsx';

		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header("Content-Disposition: attachment;filename=\"$fileName\"");

		$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
		$writer->save('php://output');
		exit;
	}
	
	public function ledgerPdf()
	{
		$db = \Config\Database::connect();

		$productId = $this->request->getGet('product_id');
		$projectId = $this->request->getGet('project_id');

		$productId = ($productId === '' || $productId === null) ? null : (int)$productId;

		$whereArr = [];

		if ($productId !== null) {
			$whereArr[] = "sl.product_id = $productId";
		}

		if ($projectId === 'general') {
			$whereArr[] = "sl.project_id IS NULL";
		} elseif (!empty($projectId)) {
			$whereArr[] = "sl.project_id = $projectId";
		}

		$where = !empty($whereArr) ? 'WHERE ' . implode(' AND ', $whereArr) : '';

		$rows = $db->query("
			SELECT sl.*, p.name AS product_name, pr.name AS project_name
			FROM stock_ledger sl
			LEFT JOIN products p ON sl.product_id = p.id
			LEFT JOIN projects pr ON sl.project_id = pr.id
			$where
			ORDER BY sl.created_at DESC
		")->getResultArray();

		// ===== PROJECT NAME =====
		$projectName = 'All Projects';

		if ($projectId === 'general') {
			$projectName = 'GENERAL PRODUCTS';
		} elseif (!empty($projectId)) {
			$projectName = $db->query("SELECT name FROM projects WHERE id = ?", [$projectId])
							  ->getRow()->name ?? '';
		}

		// ===== HTML =====
		$html = '
			<style>
				body {
					font-family: DejaVu Sans;
					font-size: 11px;
					color: #2d3748;
				}

				.header-box {
					background: #2F7E8A;
					color: #fff;
					padding: 12px;
					border-radius: 6px;
					text-align: center;
					margin-bottom: 10px;
				}

				.header-box h2 {
					margin: 0;
					font-size: 16px;
					letter-spacing: 1px;
				}

				.meta {
					text-align: center;
					font-size: 10px;
					margin-top: 4px;
					color: #e2e8f0;
				}

				.project {
					text-align: center;
					font-size: 11px;
					font-weight: bold;
					color: #2F7E8A;
					margin: 10px 0;
				}

				table {
					width: 100%;
					border-collapse: collapse;
					margin-top: 5px;
				}

				th {
					background: #3C5A82;
					color: #fff;
					padding: 7px;
					font-size: 11px;
				}

				td {
					padding: 6px;
					border: 1px solid #e2e8f0;
				}

				tr:nth-child(even) td {
					background: #f8fafc;
				}

				.right { text-align: right; }
				.center { text-align: center; }

				.in {
					color: #2e7d32;
					font-weight: bold;
				}

				.out {
					color: #c62828;
					font-weight: bold;
				}

				.footer-note {
					margin-top: 10px;
					font-size: 9px;
					text-align: right;
					color: #888;
				}
			</style>

			<div class="header-box">
				<h2>STOCK LEDGER REPORT</h2>
				<div class="meta">
					Generated On: '.date('d-m-Y h:i A').'
				</div>
			</div>

			<div class="project">
				Project: '.$projectName.'
			</div>

		<table>
			<tr>
				<th>#</th>
				<th>Date</th>
				<th>Product</th>
				<th>Type</th>
				<th>Qty</th>
				<th>Source</th>
				<th>Project</th>
			</tr>
		';

		$i = 1;

		foreach ($rows as $r) {

			$typeClass = ($r['transaction_type'] === 'IN') ? 'in' : 'out';

			$html .= '
			<tr>
				<td class="center">'.$i++.'</td>
				<td>'.$r['transaction_date'].'</td>
				<td>'.$r['product_name'].'</td>
				<td class="center '.$typeClass.'">'.$r['transaction_type'].'</td>
				<td class="right">'.number_format($r['quantity']).'</td>
				<td class="center">'.$r['source'].'</td>
				<td>'.$r['project_name'] ?: '-'.'</td>
			</tr>';
		}

		$html .= '</table>';

		// ===== DOMPDF =====
		$options = new \Dompdf\Options();
		$options->set('isRemoteEnabled', true);

		$dompdf = new \Dompdf\Dompdf($options);
		$dompdf->loadHtml($html);
		$dompdf->setPaper('A4', 'landscape'); // important for ledger
		$dompdf->render();

		$fileName = 'ledger_report_' . date('d-m-Y_H-i') . '.pdf';

		$dompdf->stream($fileName, ["Attachment" => true]);
	}
	
	public function getProductsByProject()
	{
		$db = \Config\Database::connect();
		$projectId = $this->request->getGet('project_id');

		if ($projectId === 'general') {

			// GENERAL products (no project)
			$products = $db->query("
				SELECT DISTINCT p.id, p.name
				FROM stock_ledger sl
				LEFT JOIN products p ON p.id = sl.product_id
				WHERE sl.project_id IS NULL
				  AND sl.source = 'GENERAL'
				ORDER BY p.name ASC
			")->getResultArray();

		} elseif ($projectId) {

			// PROJECT products
			$products = $db->query("
				SELECT DISTINCT p.id, p.name
				FROM stock_ledger sl
				LEFT JOIN products p ON p.id = sl.product_id
				WHERE sl.project_id = ?
				ORDER BY p.name ASC
			", [$projectId])->getResultArray();

		} else {

			// ALL products
			$products = $db->query("
				SELECT id, name FROM products ORDER BY name ASC
			")->getResultArray();
		}

		return $this->response->setJSON($products);
	}
}

<?php

namespace App\Controllers;

use App\Models\SaleModel;
use CodeIgniter\Controller;

class Payments extends Controller
{
    public function index()
    {
        $db = \Config\Database::connect();
        $data['payments'] = $db->query("
            SELECT py.*, s.invoice_no, s.total_amount,
                   p.name AS project_name, c.name AS customer_name
            FROM payments py
            LEFT JOIN sales s ON py.sale_id = s.id
            LEFT JOIN projects p ON s.project_id = p.id
            LEFT JOIN customers c ON s.customer_id = c.id
            ORDER BY py.created_at DESC
        ")->getResultArray();
        return view('payments/index', $data);
    }

    public function create($saleId = null)
    {
        $db = \Config\Database::connect();

        // Release 1.6.4 (Rule 4): total_amount/advance_applied/paid_amount/
        // balance_amount are all advance-aware already (SaleModel keeps them
        // in sync) — the dropdown's "Balance" is the pending-after-advance
        // figure straight from the column, no extra computation needed here.
        $data['sales'] = $db->query("
            SELECT s.id, s.invoice_no, s.total_amount, s.advance_applied, s.paid_amount, s.balance_amount,
                   p.name AS project_name, c.name AS customer_name
            FROM sales s
            LEFT JOIN projects p ON s.project_id = p.id
            LEFT JOIN customers c ON s.customer_id = c.id
            WHERE s.status != 'PAID'
            ORDER BY s.sale_date DESC
        ")->getResultArray();

        $data['selected_sale_id'] = $saleId;
        return view('payments/create', $data);
    }

    public function store()
    {
        $db = \Config\Database::connect();
        $saleModel = new SaleModel();

        $saleId    = (int) $this->request->getPost('sale_id');
        $amount    = (float) $this->request->getPost('amount');
        $payDate   = $this->request->getPost('payment_date');
        $method    = $this->request->getPost('method');
        $reference = $this->request->getPost('reference');
        $notes     = $this->request->getPost('notes');

        $sale = $db->query("SELECT * FROM sales WHERE id = ?", [$saleId])->getRowArray();
        if (!$sale) {
            return redirect()->back()->withInput()->with('error', 'Selected sale/invoice not found.');
        }

        // Release 1.6.4 (Rule 5): pending amount already excludes advance —
        // reject any payment that would overpay the invoice.
        $pending = (float) $sale['balance_amount'];
        if ($amount > $pending + 0.01) {
            return redirect()->back()->withInput()->with('error',
                'Payment amount (' . number_format($amount, 2) . ') exceeds the pending amount (' . number_format($pending, 2) . ') for this invoice.');
        }

        $db->transStart();

        $db->table('payments')->insert([
            'sale_id'      => $saleId,
            'amount'       => $amount,
            'payment_date' => $payDate,
            'method'       => $method,
            'reference'    => $reference,
            'notes'        => $notes,
        ]);

        // Release 1.6.4 (Rules 6-7): paid_amount/balance_amount/status
        // recomputed from source (advance_applied stays untouched — a
        // payment never re-triggers advance FIFO).
        $saleModel->recalculatePaymentState($saleId);

        $db->transComplete();
        return redirect()->to('/payments')->with('success', 'Payment recorded successfully.');
    }

    public function edit($id)
    {
        $db = \Config\Database::connect();

        $data['payment'] = $db->query("SELECT * FROM payments WHERE id=?", [$id])->getRowArray();

        $data['sales'] = $db->query("
            SELECT s.id, s.invoice_no, s.total_amount, s.advance_applied, s.paid_amount, s.balance_amount,
                   p.name AS project_name, c.name AS customer_name
            FROM sales s
            LEFT JOIN projects p ON s.project_id = p.id
            LEFT JOIN customers c ON s.customer_id = c.id
            ORDER BY s.sale_date DESC
        ")->getResultArray();

        return view('payments/edit', $data);
    }

    public function update($id)
    {
        $db = \Config\Database::connect();
        $saleModel = new SaleModel();

        $payment = $db->query("SELECT * FROM payments WHERE id=?", [$id])->getRowArray();
        if (!$payment) {
            return redirect()->to('/payments')->with('error', 'Payment not found');
        }

        $oldSaleId = (int) $payment['sale_id'];
        $oldAmount = (float) $payment['amount'];

        $newSaleId = (int) $this->request->getPost('sale_id');
        $newAmount = (float) $this->request->getPost('amount');
        $payDate   = $this->request->getPost('payment_date');
        $method    = $this->request->getPost('method');
        $reference = $this->request->getPost('reference');
        $notes     = $this->request->getPost('notes');

        $newSale = $db->query("SELECT * FROM sales WHERE id=?", [$newSaleId])->getRowArray();
        if (!$newSale) {
            return redirect()->back()->withInput()->with('error', 'Selected sale/invoice not found.');
        }

        // Release 1.6.4 (Rule 5): validate against pending recomputed as if
        // this payment's old amount were first removed — same invoice keeps
        // the room the old payment was occupying; a different invoice is
        // validated against its own current pending (untouched by this
        // payment today).
        $pendingBeforeThisPayment = ($oldSaleId === $newSaleId)
            ? (float) $newSale['balance_amount'] + $oldAmount
            : (float) $newSale['balance_amount'];

        if ($newAmount > $pendingBeforeThisPayment + 0.01) {
            return redirect()->back()->withInput()->with('error',
                'Payment amount (' . number_format($newAmount, 2) . ') exceeds the pending amount (' . number_format($pendingBeforeThisPayment, 2) . ') for this invoice.');
        }

        $db->transStart();

        $db->table('payments')->where('id', $id)->update([
            'sale_id'      => $newSaleId,
            'amount'       => $newAmount,
            'payment_date' => $payDate,
            'method'       => $method,
            'reference'    => $reference,
            'notes'        => $notes,
        ]);

        // Release 1.6.4 (Rule 6): recompute from source for the (possibly
        // two) affected invoices — advance_applied is never touched here.
        $saleModel->recalculatePaymentState($newSaleId);
        if ($oldSaleId !== $newSaleId) {
            $saleModel->recalculatePaymentState($oldSaleId);
        }

        $db->transComplete();

        return redirect()->to('/payments')->with('success', 'Payment updated successfully.');
    }

    public function delete($id)
    {
        $db = \Config\Database::connect();
        $saleModel = new SaleModel();

        $payment = $db->query("SELECT * FROM payments WHERE id=?", [$id])->getRowArray();

        $db->transStart();

        $db->table('payments')->where('id', $id)->delete();

        // Release 1.6.4 (Rule 6): recompute from source — advance_applied
        // stays attached to the project/invoice, never removed by a
        // payment deletion.
        if ($payment) {
            $saleModel->recalculatePaymentState((int) $payment['sale_id']);
        }

        $db->transComplete();
        return redirect()->to('/payments')->with('success', 'Payment deleted successfully.');
    }
}
